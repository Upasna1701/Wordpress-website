<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Arcon Containers</title>
    <!-- <link rel="icon" type="image/x-icon" href="<?php echo get_stylesheet_directory_uri(); ?>/assets/favicon/favicon-32x32white.png"> -->

</head>
<?php

wp_head();
?>
<body>
<?php get_template_part('template_parts/header/top-menu'); ?>
