!function ($) {
  "use strict";
  $(document).ready(function () {

      $('example').slick({
        slidesToShow: 3,
        arrows: false,
        dots: false,
        centerMode: false,
        autoplay: false,
        autoplaySpeed: 2000,
        infinite: true,
        cssEase: 'linear',
        touchMove: true,
        swipeToSlide: true,
        responsive: [
          {
              breakpoint: 600,
              settings: {
                  slidesToShow:1,
              }
          }
        ]
      });



  
  });
}.call(window, window.jQuery); 
