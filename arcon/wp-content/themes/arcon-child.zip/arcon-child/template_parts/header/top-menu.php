<?php if (has_nav_menu('primary')) {
    // Get the menu object
    $menu = wp_get_nav_menu_object('Header menu');
    // Get the menu items

    $menu_items = wp_get_nav_menu_items($menu);
    $menu_object = wp_get_nav_menu_object('header-menu');
    $menu_id = !empty($menu_object) ? $menu_object->term_id : '';
    
    $login_button = get_term_meta($menu_id, 'details_login_button')[0];
    $registration_button = get_term_meta($menu_id, 'details_registration_button')[0];
    $desktop_logo = get_term_meta($menu_id, 'details_desktop_logo');
    $mobile_logo = get_term_meta($menu_id, 'details_mobile_logo');
    $desktop_logo_url = wp_get_attachment_url($desktop_logo[0]);
    // echo"<pre>";print_r($login_button);exit;
    $mobile_logo_url = wp_get_attachment_url($mobile_logo[0]);
}
?>
<header>
    <div class="container">
        <div class="header-nav">
            <?php if ($desktop_logo_url) : ?>
                <a href="#" class="arcon-logo">
                    <img src="<?php echo $desktop_logo_url; ?>" alt="logo" class="logo" width="40" height="188"/>
                </a>
            <?php endif; ?>
            <div class="header-menus">
                <?php if (is_array($menu_items) && count($menu_items)) :
                    // Use wp_list_filter to filter the menu items to only include top-level (parent) menu items
                    $parent_menu_items = wp_list_filter($menu_items, array('menu_item_parent' => 0));
                    
                ?>
                    <ul class="navlink">
                        <?php foreach ($parent_menu_items as $key => $parent_menu_item) :
                            $child_menu_items = wp_list_filter($menu_items, array('menu_item_parent' => $parent_menu_item->ID));
                            if (empty($child_menu_items)) : ?>
                                <li class="nav-links"><a aria-current="page" href="<?php echo $parent_menu_item->url; ?>"><?php echo $parent_menu_item->title; ?>
                                <span>
                                    <svg _ngcontent-serverApp-c32="" xmlns="http://www.w3.org/2000/svg" width="12" height="40" viewBox="0 0 12 7.41" class="transition"><path _ngcontent-serverApp-c32="" id="ic_expand_more_24px" d="M10.59,7.41,6,2.83,1.41,7.41,0,6,6,0l6,6Z" transform="translate(12 7.41) rotate(180)"></path></svg>
                                </span></a></li>
                            <?php else : ?>
                            <!-- <li class="nav-links">
                                <a href="#">About us</a>
                                <span>
                                    <svg _ngcontent-serverApp-c32="" xmlns="http://www.w3.org/2000/svg" width="12" height="40" viewBox="0 0 12 7.41" class="transition"><path _ngcontent-serverApp-c32="" id="ic_expand_more_24px" d="M10.59,7.41,6,2.83,1.41,7.41,0,6,6,0l6,6Z" transform="translate(12 7.41) rotate(180)"></path></svg>
                                </span>
                            </li>
                            <li class="nav-links">
                                <a href="#">Dry Containers</a>
                                <span>
                                    <svg _ngcontent-serverApp-c32="" xmlns="http://www.w3.org/2000/svg" width="12" height="40" viewBox="0 0 12 7.41" class="transition"><path _ngcontent-serverApp-c32="" id="ic_expand_more_24px" d="M10.59,7.41,6,2.83,1.41,7.41,0,6,6,0l6,6Z" transform="translate(12 7.41) rotate(180)"></path></svg>
                                </span>
                            </li>
                            <li class="nav-links">
                                <a href="#">specials</a>
                                <span>
                                    <svg _ngcontent-serverApp-c32="" xmlns="http://www.w3.org/2000/svg" width="12" height="40" viewBox="0 0 12 7.41" class="transition"><path _ngcontent-serverApp-c32="" id="ic_expand_more_24px" d="M10.59,7.41,6,2.83,1.41,7.41,0,6,6,0l6,6Z" transform="translate(12 7.41) rotate(180)"></path></svg>
                                </span>
                            </li>
                            <li class="nav-links">
                                <a href="#">tanks</a>
                                <span>
                                    <svg _ngcontent-serverApp-c32="" xmlns="http://www.w3.org/2000/svg" width="12" height="40" viewBox="0 0 12 7.41" class="transition"><path _ngcontent-serverApp-c32="" id="ic_expand_more_24px" d="M10.59,7.41,6,2.83,1.41,7.41,0,6,6,0l6,6Z" transform="translate(12 7.41) rotate(180)"></path></svg>
                                </span>
                            </li>
                            <li class="nav-links">
                                <a href="#">resources</a>
                                <span>
                                    <svg _ngcontent-serverApp-c32="" xmlns="http://www.w3.org/2000/svg" width="12" height="40" viewBox="0 0 12 7.41" class="transition"><path _ngcontent-serverApp-c32="" id="ic_expand_more_24px" d="M10.59,7.41,6,2.83,1.41,7.41,0,6,6,0l6,6Z" transform="translate(12 7.41) rotate(180)"></path></svg>
                                </span>
                            </li>
                            <li class="nav-links">
                                <a href="#">contact us</a>
                                <span>
                                    <svg _ngcontent-serverApp-c32="" xmlns="http://www.w3.org/2000/svg" width="12" height="40" viewBox="0 0 12 7.41" class="transition"><path _ngcontent-serverApp-c32="" id="ic_expand_more_24px" d="M10.59,7.41,6,2.83,1.41,7.41,0,6,6,0l6,6Z" transform="translate(12 7.41) rotate(180)"></path></svg>
                                </span>
                            </li>
                            <li class="nav-links">
                                <a href="#">brochure</a>
                                <span>
                                    <svg _ngcontent-serverApp-c32="" xmlns="http://www.w3.org/2000/svg" width="12" height="40" viewBox="0 0 12 7.41" class="transition"><path _ngcontent-serverApp-c32="" id="ic_expand_more_24px" d="M10.59,7.41,6,2.83,1.41,7.41,0,6,6,0l6,6Z" transform="translate(12 7.41) rotate(180)"></path></svg>
                                </span>
                            </li> -->
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
            <div class="header-ctas">
                <?php if ($login_button) : //echo"<pre>";print_r($login_button);exit; ?>

                    <a href="<?php echo $login_button['url']; ?>" class="login-btn"><?php echo $login_button['title']; ?></a>
                <?php endif; ?>
                <?php if ($registration_button) : ?>
                    <a href="<?php echo $registration_button['url']; ?>" class="login-btn"><?php echo $registration_button['title']; ?></a>
                    <!-- <a href="#" class="register-btn">register</a> -->
                <?php endif; ?>
            </div>
        </div>
    </div>
</header>
