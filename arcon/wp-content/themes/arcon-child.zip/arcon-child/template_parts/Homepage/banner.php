<section class="main-banner" id="banner">
    <div class="container">
        <picture class="main-banner-sec-img">
            <source media="(max-width: 599px)" class="main-banner-sec-img" srcset="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/banner1-mob.webp" alt="banner-img" width="390" height="778">
            <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/banner1.webp" alt="banner-img" class="main-banner-sec-img" width="1366" height="650">
        </picture>
        <div class="main-banner-sec">
        </div>
    </div>
</section>