<?php
wp_footer(); 
?>
<?php if (has_nav_menu('primary')) {
    // Get the menu object
    $menu = wp_get_nav_menu_object('Footer menu');
    // Get the menu items
    $menu_object = wp_get_nav_menu_object('Footer menu');
    // echo"<pre>";print_r($menu);
    // echo"<pre>";print_r($menu_object);exit;
    $menu_items = wp_get_nav_menu_items($menu);
    $menu_id = !empty($menu_object) ? $menu_object->term_id : '';
    $copy_right_text = get_term_meta($menu_id, 'footer_details_copy_right_text')[0];
    $address = get_term_meta($menu_id, 'footer_details_address')[0];
    $desktop_logo = get_term_meta($menu_id, 'footer_details_footer_desktop_logo');
    $desktop_logo_url = wp_get_attachment_url($desktop_logo[0]);
}
?>

<div class="arcon-footer">
    <div class="container">
        <div class="arcon-footer-grid">
            <div class="arcon-footer-grid-col footer-logo-col">
                <?php if ($desktop_logo_url) : ?>
                    <img src="<?php echo $desktop_logo_url; ?>" alt="white-logo" class="white-logo" width="300" height="100"/>
                <?php endif; ?>
                <p class="footer-desc"><?php echo $address; ?></p>
                <div class="social-icons">
                    <!-- facebook  -->
                    <a href="https://www.facebook.com/arconcontainer/">
                        <svg _ngcontent-serverApp-c34="" id="Icon_ICON_feather_facebook_SIZE_MEDIUM_STATE_DEFAULT_STYLE_STYLE3_" data-name="Icon [ICON=feather/facebook][SIZE=MEDIUM][STATE=DEFAULT][STYLE=STYLE3]" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><rect _ngcontent-serverApp-c34="" width="20" height="20" opacity="0"></rect><g _ngcontent-serverApp-c34="" id="Icon" transform="translate(5.833 1.667)"><path _ngcontent-serverApp-c34="" id="a526835c-504d-4946-bde1-0a4e103045e0" d="M18,2H15a5,5,0,0,0-5,5v3H7v4h3v8h4V14h3l1-4H14V7a1,1,0,0,1,1-1h3Z" transform="translate(-8.333 -3.667)"></path></g></svg>
                    </a>
                    <!-- twitter  -->
                    <a href="https://twitter.com/arconcontainer?s=21&t=ZHYLAXdi7IYmmqc4V1heWg/">
                        <svg _ngcontent-serverApp-c34="" xmlns="http://www.w3.org/2000/svg" width="20" height="16.313" viewBox="0 0 20 16.313" class="twitter"><g _ngcontent-serverApp-c34="" id="Icon"><path _ngcontent-serverApp-c34="" id="_58e66d10-56e1-480f-9d8d-3aff2dc3a743" data-name="58e66d10-56e1-480f-9d8d-3aff2dc3a743" d="M20.909,2.727a9.9,9.9,0,0,1-2.854,1.391,4.073,4.073,0,0,0-7.146,2.727v.91A9.691,9.691,0,0,1,2.727,3.636S-.909,11.818,7.273,15.455A10.59,10.59,0,0,1,.909,17.273c8.182,4.545,18.182,0,18.182-10.455a4.056,4.056,0,0,0-.073-.754A7.017,7.017,0,0,0,20.909,2.727Z" transform="translate(-0.909 -2.718)"></path></g></svg>
                    </a>
                    <!-- linkedin  -->
                    <a href="https://www.linkedin.com/company/arconcontainers/">
                        <svg _ngcontent-serverApp-c34="" id="fi_3128219" height="26" viewBox="0 0 100 100" width="26" xmlns="http://www.w3.org/2000/svg" class="linkedin" style="position: relative; bottom: 3px;"><g _ngcontent-serverApp-c34="" id="_x31_0.Linkedin" transform="translate(0.001 0)"><path _ngcontent-serverApp-c34="" d="m90 90v-29.3c0-14.4-3.1-25.4-19.9-25.4-8.1 0-13.5 4.4-15.7 8.6h-.2v-7.3h-15.9v53.4h16.6v-26.5c0-7 1.3-13.7 9.9-13.7 8.5 0 8.6 7.9 8.6 14.1v26h16.6z"></path><path _ngcontent-serverApp-c34="" d="m11.3 36.6h16.6v53.4h-16.6z"></path><path _ngcontent-serverApp-c34="" d="m19.6 10c-5.3 0-9.6 4.3-9.6 9.6s4.3 9.7 9.6 9.7 9.6-4.4 9.6-9.7-4.3-9.6-9.6-9.6z"></path></g></svg>
                    </a>
                    <!-- instagram  -->
                    <a href="https://instagram.com/arconcontainer?igshid=YmMyMTA2M2Y=">
                        <svg _ngcontent-serverApp-c34="" width="20px" height="20px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><g _ngcontent-serverApp-c34="" id="Page-1" stroke="none" stroke-width="1" fill-rule="evenodd"><g _ngcontent-serverApp-c34="" id="Dribbble-Light-Preview" transform="translate(-340.000000, -7439.000000)"><g _ngcontent-serverApp-c34="" id="icons" transform="translate(56.000000, 160.000000)"><path _ngcontent-serverApp-c34="" d="M289.869652,7279.12273 C288.241769,7279.19618 286.830805,7279.5942 285.691486,7280.72871 C284.548187,7281.86918 284.155147,7283.28558 284.081514,7284.89653 C284.035742,7285.90201 283.768077,7293.49818 284.544207,7295.49028 C285.067597,7296.83422 286.098457,7297.86749 287.454694,7298.39256 C288.087538,7298.63872 288.809936,7298.80547 289.869652,7298.85411 C298.730467,7299.25511 302.015089,7299.03674 303.400182,7295.49028 C303.645956,7294.859 303.815113,7294.1374 303.86188,7293.08031 C304.26686,7284.19677 303.796207,7282.27117 302.251908,7280.72871 C301.027016,7279.50685 299.5862,7278.67508 289.869652,7279.12273 M289.951245,7297.06748 C288.981083,7297.0238 288.454707,7296.86201 288.103459,7296.72603 C287.219865,7296.3826 286.556174,7295.72155 286.214876,7294.84312 C285.623823,7293.32944 285.819846,7286.14023 285.872583,7284.97693 C285.924325,7283.83745 286.155174,7282.79624 286.959165,7281.99226 C287.954203,7280.99968 289.239792,7280.51332 297.993144,7280.90837 C299.135448,7280.95998 300.179243,7281.19026 300.985224,7281.99226 C301.980262,7282.98483 302.473801,7284.28014 302.071806,7292.99991 C302.028024,7293.96767 301.865833,7294.49274 301.729513,7294.84312 C300.829003,7297.15085 298.757333,7297.47145 289.951245,7297.06748 M298.089663,7283.68956 C298.089663,7284.34665 298.623998,7284.88065 299.283709,7284.88065 C299.943419,7284.88065 300.47875,7284.34665 300.47875,7283.68956 C300.47875,7283.03248 299.943419,7282.49847 299.283709,7282.49847 C298.623998,7282.49847 298.089663,7283.03248 298.089663,7283.68956 M288.862673,7288.98792 C288.862673,7291.80286 291.150266,7294.08479 293.972194,7294.08479 C296.794123,7294.08479 299.081716,7291.80286 299.081716,7288.98792 C299.081716,7286.17298 296.794123,7283.89205 293.972194,7283.89205 C291.150266,7283.89205 288.862673,7286.17298 288.862673,7288.98792 M290.655732,7288.98792 C290.655732,7287.16159 292.140329,7285.67967 293.972194,7285.67967 C295.80406,7285.67967 297.288657,7287.16159 297.288657,7288.98792 C297.288657,7290.81525 295.80406,7292.29716 293.972194,7292.29716 C292.140329,7292.29716 290.655732,7290.81525 290.655732,7288.98792" id="instagram-[#167]"></path></g></g></g></svg>
                    </a>
                </div>
            </div>
            <div class="arcon-footer-grid-col footer-links">
               <a href="#" class="footer-link-heading">dry containers</a>
               <a href="#" class="footer-link-sub-heading">standard boxes</a>
               <a href="#" class="footer-link-sub-heading">our services</a>
               <a href="#" class="footer-link-heading">resources</a>
               <a href="#" class="footer-link-sub-heading">articles</a>
            </div>
            <div class="arcon-footer-grid-col footer-links">
               <a href="#" class="footer-link-heading">specials</a>
               <a href="#" class="footer-link-sub-heading">special boxes</a>
               <a href="#" class="footer-link-sub-heading">our services</a>
               <a href="#" class="footer-link-heading">company</a>
               <a href="#" class="footer-link-sub-heading">management team</a>
               <a href="#" class="footer-link-sub-heading">life at arcon</a>
            </div>
            <div class="arcon-footer-grid-col footer-links">
               <a href="#" class="footer-link-heading">tanks</a>
               <a href="#" class="footer-link-sub-heading">our fleet</a>
               <a href="#" class="footer-link-sub-heading">our services</a>
            </div>
        </div>
        <div class="arcon-copyright">
            <p class="copyright"><?php echo $copy_right_text; ?></p>
            <div class="privacy-links">
                <a href="#">Privacy Policy</a>
                <a href="#">Terms of service</a>
            </div>
        </div>
    </div>
</div>




















</body>

</html>
