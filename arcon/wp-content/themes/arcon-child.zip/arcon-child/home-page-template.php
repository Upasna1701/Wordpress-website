<?php include("header.php"); 
/* Template Name: Home Page Template */?>

<main>

<?php 
get_template_part('template_parts/Homepage/banner'); 

?>

</main>

<?php include("footer.php"); ?>